globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/9zjNBPEg8Zo8LDar7-Byl/_buildManifest.js",
    "static/9zjNBPEg8Zo8LDar7-Byl/_ssgManifest.js",
    "static/9zjNBPEg8Zo8LDar7-Byl/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2u5esgrtu50t-.js",
    "static/chunks/0s2cptn1mmf6r.js",
    "static/chunks/216iyidhmrh3u.js",
    "static/chunks/10rxx6jcefiar.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/2u5esgrtu50t-.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/10rxx6jcefiar.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/2u5esgrtu50t-.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/10rxx6jcefiar.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/2u5esgrtu50t-.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/10rxx6jcefiar.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/2u5esgrtu50t-.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/10rxx6jcefiar.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/2u5esgrtu50t-.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/10rxx6jcefiar.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
