var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/src_1pr6ixxdi2k5_._.js")
R.m(23322)
module.exports=R.m(23322).exports
