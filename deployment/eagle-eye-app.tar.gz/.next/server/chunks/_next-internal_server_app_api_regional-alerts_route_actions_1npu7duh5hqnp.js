module.exports=[32199,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_regional-alerts_route_actions_1npu7duh5hqnp.js.map