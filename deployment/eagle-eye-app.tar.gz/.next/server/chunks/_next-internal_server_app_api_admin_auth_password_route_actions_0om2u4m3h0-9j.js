module.exports=[96814,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_auth_password_route_actions_0om2u4m3h0-9j.js.map