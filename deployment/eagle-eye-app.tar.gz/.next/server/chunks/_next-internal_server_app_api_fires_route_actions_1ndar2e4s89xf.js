module.exports=[21631,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fires_route_actions_1ndar2e4s89xf.js.map