module.exports=[51029,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_auth_totp_setup_route_actions_0hxltmpnebc5l.js.map