module.exports=[7351,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_content_%5Bid%5D_route_actions_0eag9ix1juvd_.js.map