module.exports=[34813,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ships_route_actions_0elbjq8jsdl9w.js.map