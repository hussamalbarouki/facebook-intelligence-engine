module.exports=[56623,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_drones_route_actions_0yeufwlkjvvl1.js.map