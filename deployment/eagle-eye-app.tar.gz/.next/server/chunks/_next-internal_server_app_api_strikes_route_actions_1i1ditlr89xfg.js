module.exports=[43410,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_strikes_route_actions_1i1ditlr89xfg.js.map