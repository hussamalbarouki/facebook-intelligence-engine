var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/telegram/route.js")
R.c("server/chunks/[root-of-the-server]__1mh2_41o7kqi9._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/src_lib_conflicts_index_ts_0fill0zba2z27._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_0wv9rn52ci6yv._.js")
R.c("server/chunks/_next-internal_server_app_api_telegram_route_actions_0scaovl3ni3g4.js")
R.m(1595)
module.exports=R.m(1595).exports
