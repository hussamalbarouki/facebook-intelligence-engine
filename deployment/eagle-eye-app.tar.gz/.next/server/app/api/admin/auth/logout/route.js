var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/logout/route.js")
R.c("server/chunks/[externals]__06zyassr3_o7q._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/_11p_q2219q_m0._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_logout_route_actions_1i7vz4_x0vr06.js")
R.m(5402)
module.exports=R.m(5402).exports
