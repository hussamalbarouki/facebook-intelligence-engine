var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/totp/setup/route.js")
R.c("server/chunks/[externals]__1k5g877ce42m6._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/[root-of-the-server]__1qepc236n-j44._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_totp_setup_route_actions_0hxltmpnebc5l.js")
R.m(29082)
module.exports=R.m(29082).exports
