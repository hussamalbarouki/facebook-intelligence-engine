var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/auth/password/route.js")
R.c("server/chunks/[externals]__0pqmw8vondg6_._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/_0jact423gh0nz._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_auth_password_route_actions_0om2u4m3h0-9j.js")
R.m(82240)
module.exports=R.m(82240).exports
