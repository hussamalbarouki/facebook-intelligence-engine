var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/intelligence/reports/route.js")
R.c("server/chunks/[root-of-the-server]__0v1nrlke98x55._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_0h30oc75791og._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/1oeh_server_app_api_admin_intelligence_reports_route_actions_1chz-k5wgge53.js")
R.m(82401)
module.exports=R.m(82401).exports
