var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/content/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0v1nrlke98x55._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_01ueqvv9j4v3o._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_content_[id]_route_actions_0eag9ix1juvd_.js")
R.m(85764)
module.exports=R.m(85764).exports
