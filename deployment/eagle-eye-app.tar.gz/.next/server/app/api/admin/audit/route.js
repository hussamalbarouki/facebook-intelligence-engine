var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/audit/route.js")
R.c("server/chunks/[externals]__0pqmw8vondg6_._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/_0k9jfnxzafcal._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_audit_route_actions_1rkls8giru8-5.js")
R.m(34304)
module.exports=R.m(34304).exports
