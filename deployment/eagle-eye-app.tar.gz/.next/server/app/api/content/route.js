var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/content/route.js")
R.c("server/chunks/[externals]__0pqmw8vondg6_._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_1vnq_yt-_auz5._.js")
R.c("server/chunks/_next-internal_server_app_api_content_route_actions_1cf1ibk6n1b1u.js")
R.m(4129)
module.exports=R.m(4129).exports
