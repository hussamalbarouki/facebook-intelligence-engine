var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ships/route.js")
R.c("server/chunks/[externals]__17m6ccbmzlpoe._.js")
R.c("server/chunks/_0j1rf7eqjb22-._.js")
R.c("server/chunks/src_lib_conflicts_index_ts_0fill0zba2z27._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_next-internal_server_app_api_ships_route_actions_0elbjq8jsdl9w.js")
R.m(80021)
module.exports=R.m(80021).exports
