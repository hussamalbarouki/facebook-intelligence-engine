var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fires/route.js")
R.c("server/chunks/[root-of-the-server]__1n6jf0zll5m50._.js")
R.c("server/chunks/_1m9naipachr_a._.js")
R.c("server/chunks/node_modules_@xmldom_xmldom_lib_1p70-7msch67q._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_conflicts_index_ts_0fill0zba2z27._.js")
R.c("server/chunks/_next-internal_server_app_api_fires_route_actions_1ndar2e4s89xf.js")
R.m(10483)
module.exports=R.m(10483).exports
