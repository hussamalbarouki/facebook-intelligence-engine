var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/telegram/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__00k_bgdxcl_qu._.js")
R.c("server/chunks/src_lib_admin_security_ts_1ndgaomjjs_pq._.js")
R.c("server/chunks/_0n5hi1jsy7mei._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_admin_storage_ts_04glc_sx69o-_._.js")
R.c("server/chunks/1oeh_server_app_api_integrations_telegram_webhook_route_actions_1rrxk4s5g9krm.js")
R.m(74869)
module.exports=R.m(74869).exports
