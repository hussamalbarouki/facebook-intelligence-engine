1:"$Sreact.fragment"
2:"/_next/static/chunks/3wnr7rjplu4d_.js"
3:I[97703,["$2"],"ThemeProvider"]
4:"ConflictProvider"
5:I[94615,["$2"],"$4"]
6:I[39756,["$2"],"default"]
7:I[37457,["$2"],"default"]
c:I[47257,["$2"],"ClientPageRoot"]
d:"/_next/static/chunks/0k0l9qktsea4e.js"
e:I[1182,["$2","$d"],"default"]
11:I[97367,["$2"],"OutletBoundary"]
12:"$Sreact.suspense"
14:"ViewportBoundary"
15:I[97367,["$2"],"$14"]
17:"MetadataBoundary"
18:I[97367,["$2"],"$17"]
1a:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/2xf8mwqws5g23.css","style"]
:HL["https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Noto+Kufi+Arabic:wght@400;600;700&display=swap","style"]
a:X
b:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$Lc",null,{"Component":"$e","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@f","$@10"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/0k0l9qktsea4e.js","async":true,"nonce":"$undefined"}]],["$","$L11",null,{"children":["$","$12",null,{"name":"Next.MetadataOutlet","children":"$@13"}]}]]}],"p":false,"v":null}}]]
9:[["children",{"s":"login","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$a"},"c":"$Qb"}]]
8:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":null},"c":"$Q9"}]]
0:{"P":null,"c":["","admin","login"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2xf8mwqws5g23.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3wnr7rjplu4d_.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"ar","suppressHydrationWarning":true,"children":[["$","head",null,{"children":[["$","script",null,{"dangerouslySetInnerHTML":{"__html":"(function(){try{var d=document.documentElement;var t=localStorage.getItem('eagle-eye-theme');var m=localStorage.getItem('eagle-eye-mode');var ok=[\"mono\",\"cyan\",\"amber\",\"nvg\",\"red\",\"violet\",\"ice\"];if(t&&t!=='mono'&&ok.indexOf(t)>-1)d.setAttribute('data-theme',t);if(m==='light')d.setAttribute('data-mode','light');}catch(e){}})();"}}],["$","link",null,{"href":"https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Noto+Kufi+Arabic:wght@400;600;700&display=swap","rel":"stylesheet"}]]}],["$","body",null,{"className":"scanlines antialiased","children":["$","$L3",null,{"children":["$","$L5",null,{"children":["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}]]}],"p":false,"v":null},"c":"$Q8"},"h":{"r":["$","$1","h",{"children":[null,["$","$L15",null,{"children":"$L16"}],["$","$L18",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$12",null,{"name":"Next.Metadata","children":"$L19"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$1a",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2xf8mwqws5g23.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"9zjNBPEg8Zo8LDar7-Byl"}
a:C
f:{}
10:"$b:0:1:d:r:props:children:0:props:serverProvidedParams:params"
16:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1b:I[27201,["$2"],"IconMark"]
13:null
19:[["$","title","0",{"children":"لوحة القيادة | شعبة المعلومات - عين النسر"}],["$","meta","1",{"name":"description","content":"منصة الرصد والتحليل المعلوماتي التابعة لشعبة المعلومات ضمن منظومة عين النسر."}],["$","meta","2",{"name":"application-name","content":"شعبة المعلومات - عين النسر"}],["$","meta","3",{"name":"author","content":"منظومة عين النسر - شعبة المعلومات"}],["$","meta","4",{"name":"keywords","content":"OSINT,dashboard,Iran,Israel,Russia,Ukraine,conflict monitor,air raid alerts,drone tracker"}],["$","meta","5",{"name":"robots","content":"noindex, nofollow"}],["$","link","6",{"rel":"shortcut icon","href":"/eagle-eye-icon.png"}],["$","link","7",{"rel":"icon","href":"/eagle-eye-icon.png"}],["$","link","8",{"rel":"apple-touch-icon","href":"/eagle-eye-logo.png"}],["$","$L1b","9",{}]]
