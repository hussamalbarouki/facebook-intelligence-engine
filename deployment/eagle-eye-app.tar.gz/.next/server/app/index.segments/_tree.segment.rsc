:HL["/_next/static/chunks/2xf8mwqws5g23.css","style"]
:HL["https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Noto+Kufi+Arabic:wght@400;600;700&display=swap","style"]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"9zjNBPEg8Zo8LDar7-Byl","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
